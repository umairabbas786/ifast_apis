<?php require "app/Manifest.php";
(new ChangePartnerStatus())->launch();