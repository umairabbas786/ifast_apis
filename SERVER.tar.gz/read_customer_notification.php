<?php require "app/Manifest.php";
(new ReadCustomerNotification())->launch();