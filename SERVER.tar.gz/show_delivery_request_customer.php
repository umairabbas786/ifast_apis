<?php require "app/Manifest.php";
(new ShowDeliveryRequestCustomer())->launch();