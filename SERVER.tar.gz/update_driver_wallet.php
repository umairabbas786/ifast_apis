<?php require "app/Manifest.php";
(new UpdateDriverWallet())->launch();