<?php require "app/Manifest.php";
(new ShowDeliveryBill())->launch();