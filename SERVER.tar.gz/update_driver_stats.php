<?php require "app/Manifest.php";
(new UpdateDriverStats())->launch();