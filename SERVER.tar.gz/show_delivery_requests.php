<?php require "app/Manifest.php";
(new ShowDeliveryRequests())->launch();