<?php require "app/Manifest.php";
(new SendMessage())->launch();