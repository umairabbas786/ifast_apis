<?php require "app/Manifest.php";
(new StatsDriver())->launch();