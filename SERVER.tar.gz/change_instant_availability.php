<?php require "app/Manifest.php";
(new ChangeInstantAvailability())->launch();