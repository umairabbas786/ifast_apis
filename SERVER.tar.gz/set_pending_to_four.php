<?php require "app/Manifest.php";
(new SetPendingToFour())->launch();