<?php require "app/Manifest.php";
(new CreateCustomerDepositRequest())->launch();