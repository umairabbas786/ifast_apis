<?php require "app/Manifest.php";
(new CustomerConfirmDeliveryRequest())->launch();