<?php require "app/Manifest.php";
(new GetPartnerType())->launch();