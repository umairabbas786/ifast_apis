<?php require "app/Manifest.php";
(new DriverNotification())->launch();