<?php require "app/Manifest.php";
(new CreateDeliveryBill())->launch();