<?php require "app/Manifest.php";
(new UpdatePostAdStatus())->launch();