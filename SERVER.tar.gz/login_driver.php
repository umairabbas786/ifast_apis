<?php require "app/Manifest.php";
(new LoginDriver())->launch();