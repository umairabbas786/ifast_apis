<?php require "app/Manifest.php";
(new MakeDeliveryCustomer())->launch();