<?php require "app/Manifest.php";
(new ShowDriverPartners())->launch();