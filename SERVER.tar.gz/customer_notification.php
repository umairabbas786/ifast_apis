<?php require "app/Manifest.php";
(new CustomerNotification())->launch();