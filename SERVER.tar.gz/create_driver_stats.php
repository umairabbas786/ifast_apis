<?php require "app/Manifest.php";
(new CreateDriverStats())->launch();