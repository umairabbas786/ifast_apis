<?php require "app/Manifest.php";
(new PostAnAds())->launch();