<?php require "app/Manifest.php";
(new GetAllPosts())->launch();