<?php require "app/Manifest.php";
(new PaymentGenerator())->launch();