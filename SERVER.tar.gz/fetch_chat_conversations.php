<?php require "app/Manifest.php";
(new FetchChatConversations())->launch();