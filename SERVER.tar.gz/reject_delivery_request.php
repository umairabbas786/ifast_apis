<?php require "app/Manifest.php";
(new RejectDeliveryRequest())->launch();