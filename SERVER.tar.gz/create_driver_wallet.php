<?php require "app/Manifest.php";
(new CreateDriverWallet())->launch();