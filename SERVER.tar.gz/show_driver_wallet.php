<?php require "app/Manifest.php";
(new ShowDriverWallet())->launch();