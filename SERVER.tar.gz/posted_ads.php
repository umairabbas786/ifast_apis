<?php require "app/Manifest.php";
(new PostedAds())->launch();