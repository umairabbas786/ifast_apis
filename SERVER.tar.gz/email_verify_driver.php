<?php require "app/Manifest.php";
(new EmailVerifyDriver())->launch();