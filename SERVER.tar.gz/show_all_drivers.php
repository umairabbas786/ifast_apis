<?php require "app/Manifest.php";
(new ShowAllDrivers())->launch();