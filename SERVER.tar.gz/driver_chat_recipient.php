<?php require "app/Manifest.php";
(new DriverChatRecipient())->launch();