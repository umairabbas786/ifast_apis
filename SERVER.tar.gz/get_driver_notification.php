<?php require "app/Manifest.php";
(new GetDriverNotification())->launch();