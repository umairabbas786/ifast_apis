<?php require "app/Manifest.php";
(new ReadDriverNotification())->launch();