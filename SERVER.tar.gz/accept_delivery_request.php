<?php require "app/Manifest.php";
(new AcceptDeliveryRequest())->launch();