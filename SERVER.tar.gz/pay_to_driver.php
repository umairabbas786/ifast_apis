<?php require "app/Manifest.php";
(new PayToDriver())->launch();