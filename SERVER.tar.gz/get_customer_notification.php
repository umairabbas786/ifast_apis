<?php require "app/Manifest.php";
(new GetCustomerNotification())->launch();