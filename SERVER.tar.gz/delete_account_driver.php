<?php require "app/Manifest.php";
(new DeleteAccountDriver())->launch();