<?php require "app/Manifest.php";
(new ChangeDriverAvailabilityStatus())->launch();