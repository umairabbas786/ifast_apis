<?php require "app/Manifest.php";
(new MakePartnerDriver())->launch();