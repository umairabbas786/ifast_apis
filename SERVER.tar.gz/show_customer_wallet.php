<?php require "app/Manifest.php";
(new ShowCustomerWallet())->launch();