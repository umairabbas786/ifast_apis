<?php require "app/Manifest.php";
(new RegisterDriver())->launch();