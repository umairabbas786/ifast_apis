<?php require "app/Manifest.php";
(new ChangePendingStatusOfDelivery())->launch();