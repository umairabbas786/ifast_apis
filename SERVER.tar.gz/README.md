# i_fast_api

Project created using create_electro_app at 20-Nov-2021 00:40:30

Thanks for using CEA
