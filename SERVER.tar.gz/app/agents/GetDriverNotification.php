<?php

class GetDriverNotification extends ElectroApi {

    const DRIVER_ID = "driver_id";

    protected function onAssemble() {
        if (!isset($_POST[self::DRIVER_ID])) {
            $this->killAsBadRequestWithMissingParamException(self::DRIVER_ID);
        }
    }

    protected function onDevise() {
        $Notifications = $this->getAppDB()->getDriver_notificationDao()
            ->getDriverNotificationWithDriverId($_POST[self::DRIVER_ID]);

        if(count($Notifications) === 0) {
            $this->killAsFailure([
                'no_data_found' => true
            ]);
        }

        $ad = [];

        /** @var Driver_notificationEntity $adds */
        foreach ($Notifications as $ads) {
            array_push($ad, [
                Driver_notificationTableSchema::ID => $ads->getId(),
                Driver_notificationTableSchema::MSG => $ads->getMsg(),
                Driver_notificationTableSchema::STATE => $ads->isState(),
                Driver_notificationTableSchema::CREATED_AT => $ads->getCreatedAt()
            ]);
        }

        $this->resSendOK([
            'driver_notifications' => $ad
        ]);
    }
}
